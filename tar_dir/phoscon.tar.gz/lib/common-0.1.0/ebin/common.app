{application,common,
             [{description,"An OTP library"},
              {vsn,"0.1.0"},
              {registered,[]},
              {applications,[kernel,stdlib]},
              {env,[]},
              {modules,[common,lib_git,lib_vm]},
              {licenses,["Apache-2.0"]},
              {links,[]}]}.
